/**
 * Filename : manifest.js
 * created by Nikola Lukic zlatnaspirala@gmail.com
 * https://maximumroulette.com 2016-2020
 */

var APPLICATION = {
  NAME: "WOLF-360-PLAYER",
  TYPE: "client app",
  VERSION: "0.1",
  STATUS: "develop",
  DEVELOPERS: ["Nikola Lukic zlatnaspirala@gmail.com"]
};

var PROGRAM = {
  NAME: "Three.js used ,based on visula-js",
  GRID: false,
  AUTO_UPDATE: [],
  ANTIALIAS: true,
  SKY: false,
  LIGHTS: true
};
