/*
 * @Method render
 */
function render() {
  renderer.render(scene, camera);
}
