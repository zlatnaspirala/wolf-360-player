# Little Iframe Tool to easily generate marker
- one can generate easily any aruco marker based only on maker id
- it make use of aruco-marker
  - https://github.com/bhollis/aruco-marker



---

### Possible Improvement
- have a caption which give the marker id on the screen
  - it helps during development to identify all the markers
